# Domain For Sale Landing Page

I created a free webpage template to sale your domain.
It's Fast and efficiently and purchaser can email you throught this free template.

## To Use 
You can clone folder & host on you server. But you need to change certain elements.
- Page title 
- Domain sale price 
- Email address on index & contact page 
- Phone Number
- Your name and other information